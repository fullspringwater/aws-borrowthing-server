class Config :
    JWT_SECRET_KEY = 'borrowthing#yh#0918'
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True

    # AWS fullspringwater
    ACCESS_KEY = 'AKIAVU7KEYR5XIY6N7OW'
    SECRET_ACCESS = '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'

    # S3 버킷이름과, 기본 URL 주소 셋팅
    S3_BUCKET = 'borrowthing-images'
    S3_LOCATION ='https://borrowthing-images.s3.amazonaws.com/'

    NAVER_PAPAGO_URL = 'https://openapi.naver.com/v1/papago/n2mt'

    NAVER_CLIENT_ID = '8vqgK6wVauQ0FivLtyBP'
    NAVER_CLIENT_SECRET = 'oxAXTlgFAz'