class Config :
    JWT_SECRET_KEY = 'borrowthing#yh#0918'
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True

    # AWS fullspringwater
    ACCESS_KEY = 'AKIAVU7KEYR5745POGUD'
    SECRET_ACCESS = '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'

    # S3 버킷이름과, 기본 URL 주소 셋팅
    S3_BUCKET = 'borrowthing-images'
    S3_LOCATION ='https://borrowthing-images.s3.amazonaws.com/'