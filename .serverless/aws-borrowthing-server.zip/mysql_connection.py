import mysql.connector

def get_connection() :
    connection = mysql.connector.connect(
        host = 'yh-db.cesawiuivilv.ap-northeast-2.rds.amazonaws.com',
        database = 'borrowthing_db',
        user = 'borrow_user',
        password = 'borrow12',
    )
    return connection

